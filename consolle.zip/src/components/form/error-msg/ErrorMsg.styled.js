import styled from '@emotion/styled';

export const ErrorMsg = styled.div`
  font-size: 12px;
  padding-top: 5px;
  color: #d32f2f;
`;
