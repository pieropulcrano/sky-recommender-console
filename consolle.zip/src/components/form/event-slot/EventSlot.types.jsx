export const slotTypes = {
  NONE: 'none',
  HD: 'hd',
  SD: 'sd',
};
