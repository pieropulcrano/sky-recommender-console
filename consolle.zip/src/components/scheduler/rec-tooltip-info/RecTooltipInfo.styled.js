import styled from '@emotion/styled';

export const TooltipContentWrapper = styled.div`
  display: flex;
  flex-direction: column;
`;

export const RecInfoWrapper = styled.div`
  display: flex;
  flex-direction: column;
`;

export const TooltipWrapper = styled.div`
  display: flex;
  flex-direction: flex-start;
`;
