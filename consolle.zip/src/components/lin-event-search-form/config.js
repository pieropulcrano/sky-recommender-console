/**
 * Initial values passed to the form.
 */

export const initialValues = {
  title: null,
  startDateTime: null,
};
