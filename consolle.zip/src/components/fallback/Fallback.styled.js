import styled from '@emotion/styled';

export const FallbackWrapper = styled.div`
  display: flex;
  flex-direction: column;
  height: 70vh;
  align-items: center;
  justify-content: center;
`;
